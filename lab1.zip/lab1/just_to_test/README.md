### Cmake Options (ctrl+alt+s)
```
-DCMAKE_PREFIX_PATH=/home/{$USER}/lib/cmake/unum/
-DCMAKE_BUILD_TYPE=Debug
```

### Биндинг к numpy 

[У тебя получится %username%](https://docs.scipy.org/doc/numpy/reference/c-api.array.html)