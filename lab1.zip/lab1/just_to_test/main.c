#include <stdio.h>
#include "unum/posit.h"

int main() {
	int a = test_function();
	printf("%d\n", a);
	return 0;
}