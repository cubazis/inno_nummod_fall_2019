#ifndef __POSIT_OP1_H
#define __POSIT_OP1_H

#ifdef __cplusplus
extern "C" {
#endif

#include "pack.h"

struct unpacked_t op1_sqrt(struct unpacked_t a);

#ifdef __cplusplus
}
#endif

#endif
